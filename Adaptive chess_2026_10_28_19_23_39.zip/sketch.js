let bg;
let ybar = 384;
let barspeed = 5;
let direction = -1;
let holding = false;
let result = "";
let points = 0;
async function setup() {
createCanvas(1280, 720);
bg = await loadImage("Act4Background.png");
}
function draw() {
if (bg) {
image(bg, 0, 0, width, height);
}
noStroke();
fill(240, 180, 115);
rect(903, 198, 64, 438, 8);
fill(255, 0, 0);
rect(913, 208, 44, 414, 5);
fill(255, 255, 0);
rect(913, 294, 44, 78, 5);
fill(0, 255, 0);
rect(913, 372, 44, 36);
fill(255, 255, 0);
rect(913, 408, 44, 78, 5);
fill(240, 180, 115);
ellipse(934, 642, 114, 96);
fill(250, 128, 114)
ellipse(1120, 390, 180, 180);
fill(255, 255, 255);
textSize(32);
text("HOLD", 1075, 400);
fill(255, 255, 255);
textSize(32);
text(result, 720, 480);
if (holding) {
ybar += barspeed * direction;
if (ybar <= 216) {
ybar = 216;
direction = 1;
}
if (ybar >= 600) {
ybar = 600;
direction = -1;
}
}
fill(150);
stroke(100);
strokeWeight(2);
rect(889, ybar, 92, 12);
}
function mousePressed() {
if(mouseX>1120 - 90 && mouseX<1200 && mouseY>390 - 90 && mouseY<390 + 90){
holding = true;
result = "";
}
}
function mouseReleased() {
holding = false;
if(ybar > 372 && ybar < 372+36){
result = "wow";
}
if(ybar > 294 && ybar < 294 + 77){
result = "nah"
}
if(ybar > 408 && ybar < 408 + 77){
result = "nah"
}
if(ybar > 208 && ybar < 208 + 85){
result = "nahh"
}
if(ybar > 486 && ybar < 486 + 139){
result = "nahh"
}
}