let bg;
let ybar = 384;
let barspeed = 5;
let direction = -1;
let holding = false;
let points = 0;
let totalstars = 0;
let start = false;
let popup = false;
let gameover = false;
async function setup() {
createCanvas(1280, 720);
bg = await loadImage("Act4Background.png");
}
function draw() {
if (!start) {
background(173, 88, 43);
noStroke();
textAlign(CENTER, CENTER);
fill(255);
textSize(52);
text("Level 4", 640, 80);
fill(255, 239, 204);
rect(390, 120, 500, 480, 12);
fill(80);
textSize(36);
text("Instructions", 640, 170);
textSize(27);
text("Hold down the button to move", 640, 265);
text("the temperature bar. Release", 640, 305);
text("the button when the bar is in", 640, 345);
text("the green zone!", 640, 385);
textSize(23);
text("You have one try per pizza.", 640, 445);
text("Each pizza gets faster!", 640, 480);
text("Earn up to 5 stars!", 640, 515);
fill(250, 128, 114);
rect(530, 620, 220, 65, 12);
fill(255);
textSize(28);
text("CONTINUE", 640, 652);
return;
}
if (gameover) {
background(40, 94, 78);
noStroke();
fill(255, 218, 105);
triangle(120, 130, 340, 130, 200, 210);
triangle(120, 300, 340, 300, 200, 210);
triangle(1160, 130, 940, 130, 1080, 210);
triangle(1160, 300, 940, 300, 1080, 210);
fill(255, 229, 158);
rect(270, 95, 740, 225, 35);
fill(0);
textAlign(CENTER, CENTER);
textSize(52);
text("Level Complete", 640, 200);
textSize(32);
text("Accuracy: " + totalstars * 20 + "%", 640, 265);
for (let i = 0; i < 5; i++) {
fill(i < totalstars ? color(255, 215, 0) : color(230));
star(350 + i * 145, 440, 25, 55);
}
fill(80, 230, 40);
rect(390, 590, 500, 80, 12);
fill(0);
textSize(30);
text("Next Level", 640, 630);
return;
}
image(bg, 0, 0, width, height);
noStroke();
fill(240, 180, 115);
rect(903, 198, 64, 438, 8);
fill(255, 0, 0);
rect(913, 208, 44, 414, 5);
fill(255, 255, 0);
rect(913, 294, 44, 78, 5);
rect(913, 408, 44, 78, 5);
fill(0, 255, 0);
rect(913, 372, 44, 36);
fill(240, 180, 115);
ellipse(934, 642, 114, 96);
fill(250, 128, 114);
ellipse(1120, 390, 180, 180);
fill(255);
textAlign(LEFT, BASELINE);
textSize(32);
text("HOLD", 1075, 400);
textSize(28);
text("Pizzas Completed: " + points + "/3", 950, 100);
if (holding && !popup) {
ybar += barspeed * direction;
if (ybar <= 216 || ybar >= 600) {
direction *= -1;
}
ybar = constrain(ybar, 216, 600);
}
fill(150);
stroke(100);
strokeWeight(2);
rect(889, ybar, 92, 12);
if (popup) {
noStroke();
fill(0, 0, 0, 150);
rect(0, 0, 1280, 720);
fill(240, 180, 115);
rect(390, 220, 500, 280, 20);
fill(255);
textAlign(CENTER, CENTER);
textSize(36);
text("Good Job!", 640, 315);
fill(250, 128, 114);
rect(530, 385, 220, 65, 12);
fill(255);
textSize(28);
text("CONTINUE", 640, 417);
}
}
function mousePressed() {
if (!start) {
if (mouseX > 530 && mouseX < 750 &&
mouseY > 620 && mouseY < 685) start = true;
return;
}
if (gameover) {
if (mouseX > 390 && mouseX < 890 &&
mouseY > 590 && mouseY < 670) {
}
return;
}
if (popup) {
if (mouseX > 530 && mouseX < 750 &&
mouseY > 385 && mouseY < 450) {
popup = false;
ybar = 384;
direction = -1;
}
return;
}
if (dist(mouseX, mouseY, 1120, 390) < 90) {
holding = true;
}
}
function mouseReleased() {
if (!holding || popup || gameover) return;
holding = false;
if (ybar >= 372 && ybar <= 408) {
totalstars += points == 0 ? 1 : 2;
}
else if (ybar >= 294 && ybar <= 486) {
if (points > 0) totalstars++;
}
points++;
if (points == 3) {
gameover = true;
}
else {
barspeed += 3;
popup = true;
}
}
function star(x, y, r1, r2) {
beginShape();
for (let i = 0; i < 10; i++) {
let a = -HALF_PI + i * PI / 5;
let r = i % 2 == 0 ? r2 : r1;
vertex(x + cos(a) * r, y + sin(a) * r);
}
endShape(CLOSE);
}