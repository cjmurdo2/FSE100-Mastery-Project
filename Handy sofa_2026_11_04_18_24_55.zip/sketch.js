let woodBg,sauceLayer,chosenShape="Circle",screen="instructions",pizzaX=610,pizzaY=330,sauceBoundary=165,brushSize=38,gameStarted=false,gameFinished=false,currentPizza=1,totalPizzas=3,pizzaScores=[],pizzaStars=[],totalSauce=0,goodSauce=0,accuracy=0,ladleX=610,ladleY=330,lastSauceX=null,lastSauceY=null,coveragePoints=[],coverageSpacing=10,shapes=["Circle","Square","Star","Heart","Triangle"];

async function setup(){
createCanvas(1120,622);
woodBg=await loadImage("Seamless Honey-Brown Woodgrain Planks (1).png");
sauceLayer=createGraphics(width,height);sauceLayer.clear();createCoveragePoints();
}
function draw(){
if(screen==="instructions")drawInstructions();
else if(screen==="game")drawGame();
else drawLevelComplete();
}
function drawInstructions(){
image(woodBg,0,0,width,height);
noStroke();fill(255);textAlign(CENTER,CENTER);textSize(38);text("Level 2",560,65);
fill(255,248,225,245);stroke(225,205,165);strokeWeight(2);rectMode(CENTER);rect(560,320,410,400);
noStroke();fill(70);textSize(27);text("Instructions",560,170);
textSize(25);text("Select a shape. Then use one\nfinger to spread sauce on the\npizza within the lines of the\nshape!",560,320);
fill(240,180,115);stroke(130,85,50);strokeWeight(3);rect(560,445,180,50,8);
noStroke();fill(0);textSize(30);text("NEXT",560,445);rectMode(CORNER);
}
function drawGame(){
image(woodBg,0,0,width,height);drawPizza();image(sauceLayer,0,0);drawSelectedShape();drawSidebar();drawPizzaNumber();drawAccuracyBar();drawSauceJar();updateLadle();drawLadle();
if(gameStarted&&!gameFinished)drawFinishButton();
if(gameFinished)drawPizzaResults();
}
function drawPizza(){
fill(255,230,157);stroke(130,105,65);strokeWeight(2);ellipse(pizzaX,pizzaY,380,380);
noFill();ellipse(pizzaX,pizzaY,340,340);
noStroke();fill(255);textAlign(CENTER,CENTER);textSize(36);text("Add The Sauce",560,75);
}
function drawPizzaNumber(){
noStroke();fill(0,0,0,135);rect(825,225,250,55,12);
fill(255);textAlign(CENTER,CENTER);textSize(20);text("Pizza "+currentPizza+" of "+totalPizzas,950,252);
}
function drawSidebar(){
noFill();stroke(220,195,155);strokeWeight(1);rect(55,135,255,320,10);
noStroke();fill(255);textAlign(LEFT,CENTER);textSize(20);text("Pizza Shapes",85,165);textSize(18);
for(let i=0;i<5;i++){
let y=215+i*48;fill(255);noStroke();text(shapes[i],120,y);noFill();stroke(255);strokeWeight(2);rect(80,y-7,14,14);
if(chosenShape===shapes[i]){noStroke();fill(255,210,90);rect(83,y-4,8,8);}
}}
function drawSelectedShape(){
noFill();stroke(110,80,55);strokeWeight(4);drawingContext.setLineDash([12,8]);
if(chosenShape==="Circle")ellipse(pizzaX,pizzaY,290,290);
else if(chosenShape==="Square"){rectMode(CENTER);rect(pizzaX,pizzaY,230,230);rectMode(CORNER);}
else if(chosenShape==="Star")drawStar(pizzaX,pizzaY,75,158,5);
else if(chosenShape==="Heart"){let h=getHeartPoints();beginShape();for(let i=0;i<h.length;i++)vertex(h[i].x,h[i].y);endShape(CLOSE);}
else{beginShape();vertex(pizzaX,pizzaY-155);vertex(pizzaX-145,pizzaY+95);vertex(pizzaX+145,pizzaY+95);endShape(CLOSE);}
drawingContext.setLineDash([]);
}
function drawStar(x,y,a,b,n){
let d=TWO_PI/n,h=d/2;beginShape();
for(let t=-HALF_PI;t<TWO_PI-HALF_PI;t+=d){vertex(x+cos(t)*b,y+sin(t)*b);vertex(x+cos(t+h)*a,y+sin(t+h)*a);}
endShape(CLOSE);
}
function getHeartPoints(){
let p=[];
for(let i=0;i<120;i++){
let t=map(i,0,120,0,TWO_PI),x=16*pow(sin(t),3),y=13*cos(t)-5*cos(2*t)-2*cos(3*t)-cos(4*t);
p.push({x:pizzaX+x*8.7,y:pizzaY-y*8.7});
}return p;
}
function updateLadle(){
if(gameStarted&&!gameFinished&&dist(mouseX,mouseY,pizzaX,pizzaY)<=sauceBoundary){ladleX=mouseX;ladleY=mouseY;}
}
function drawLadle(){
push();
stroke(90,90,90,100);strokeWeight(14);line(ladleX+18,ladleY-8,ladleX+105,ladleY-95);
stroke(180);strokeWeight(11);line(ladleX+15,ladleY-10,ladleX+102,ladleY-97);
stroke(235);strokeWeight(3);line(ladleX+18,ladleY-13,ladleX+99,ladleY-94);
fill(170);stroke(90);strokeWeight(3);ellipse(ladleX,ladleY,58,47);
noStroke();fill(175,35,25);ellipse(ladleX,ladleY+3,43,31);fill(220,70,45,150);ellipse(ladleX-5,ladleY-2,18,9);pop();
}
function startSauce(){
if(!gameStarted||gameFinished||dist(mouseX,mouseY,pizzaX,pizzaY)>sauceBoundary)return;
lastSauceX=ladleX=mouseX;lastSauceY=ladleY=mouseY;paintSauceAt(mouseX,mouseY);
}
function spreadSauce(){
if(!gameStarted||gameFinished)return;
if(dist(mouseX,mouseY,pizzaX,pizzaY)>sauceBoundary){stopSauce();return;}
ladleX=mouseX;ladleY=mouseY;
if(lastSauceX===null){lastSauceX=mouseX;lastSauceY=mouseY;paintSauceAt(mouseX,mouseY);return;}
let d=dist(lastSauceX,lastSauceY,mouseX,mouseY),s=max(1,ceil(d/2));
for(let i=1;i<=s;i++){let n=i/s;paintSauceAt(lerp(lastSauceX,mouseX,n),lerp(lastSauceY,mouseY,n));}
lastSauceX=mouseX;lastSauceY=mouseY;calculateAccuracy();
}
function paintSauceAt(x,y){
if(dist(x,y,pizzaX,pizzaY)>sauceBoundary-brushSize/2)return;
sauceLayer.noStroke();sauceLayer.fill(188,42,28,245);sauceLayer.ellipse(x,y,brushSize,brushSize);
sauceLayer.fill(205,52,32,100);sauceLayer.ellipse(x-2,y-2,brushSize-7,brushSize-7);
totalSauce++;if(pointInsideSelectedShape(x,y))goodSauce++;markCoverage(x,y);calculateAccuracy();
}
function stopSauce(){lastSauceX=null;lastSauceY=null;}
function createCoveragePoints(){
coveragePoints=[];
for(let x=pizzaX-sauceBoundary;x<=pizzaX+sauceBoundary;x+=coverageSpacing){
for(let y=pizzaY-sauceBoundary;y<=pizzaY+sauceBoundary;y+=coverageSpacing){
if(pointInsideSelectedShape(x,y))coveragePoints.push({x:x,y:y,covered:false});
}}}
function markCoverage(x,y){
for(let i=0;i<coveragePoints.length;i++){
let p=coveragePoints[i];
if(!p.covered&&dist(x,y,p.x,p.y)<=brushSize/2)p.covered=true;
}}
function calculateAccuracy(){
let c=0;
for(let i=0;i<coveragePoints.length;i++)if(coveragePoints[i].covered)c++;
let coverage=coveragePoints.length?c/coveragePoints.length:0;
let precision=totalSauce?goodSauce/totalSauce:1;
accuracy=constrain(coverage*precision*100,0,100);
}
function pointInsideSelectedShape(x,y){
let dx=x-pizzaX,dy=y-pizzaY;
if(chosenShape==="Circle")return dist(x,y,pizzaX,pizzaY)<=145;
if(chosenShape==="Square")return abs(dx)<=115&&abs(dy)<=115;
if(chosenShape==="Triangle")return pointInTriangle(x,y,pizzaX,pizzaY-155,pizzaX-145,pizzaY+95,pizzaX+145,pizzaY+95);
if(chosenShape==="Heart")return pointInPolygon(x,y,getHeartPoints());
let p=[],a=TWO_PI/5,h=a/2;
for(let n=-HALF_PI;n<TWO_PI-HALF_PI;n+=a){p.push({x:pizzaX+cos(n)*158,y:pizzaY+sin(n)*158});p.push({x:pizzaX+cos(n+h)*75,y:pizzaY+sin(n+h)*75});}
return pointInPolygon(x,y,p);
}
function pointInTriangle(px,py,x1,y1,x2,y2,x3,y3){
let d=(y2-y3)*(x1-x3)+(x3-x2)*(y1-y3),a=((y2-y3)*(px-x3)+(x3-x2)*(py-y3))/d,b=((y3-y1)*(px-x3)+(x1-x3)*(py-y3))/d,c=1-a-b;
return a>=0&&b>=0&&c>=0;
}
function pointInPolygon(x,y,p){
let inside=false;
for(let i=0,j=p.length-1;i<p.length;j=i++)if(((p[i].y>y)!==(p[j].y>y))&&(x<(p[j].x-p[i].x)*(y-p[i].y)/(p[j].y-p[i].y)+p[i].x))inside=!inside;
return inside;
}
function drawAccuracyBar(){
noStroke();fill(0,0,0,135);rect(825,105,250,105,12);fill(255);textAlign(CENTER,CENTER);textSize(19);text("Accuracy",950,132);
fill(75);rect(850,158,200,22,11);
if(accuracy>=80)fill(70,200,90);else if(accuracy>=50)fill(240,180,50);else fill(220,60,50);
rect(850,158,map(accuracy,0,100,0,200),22,11);fill(255);textSize(15);text(floor(accuracy)+"%",950,195);
}
function drawSauceJar(){
push();noStroke();fill(0,0,0,60);ellipse(945,515,165,30);
fill(230,235,230);stroke(100);strokeWeight(3);rect(870,335,150,180,22);
noStroke();fill(175,35,25);rect(880,390,130,112,15);ellipse(945,393,130,25);
fill(250,225,180);rect(877,420,136,55,8);fill(165,35,25);textAlign(CENTER,CENTER);textSize(23);text("PIZZA",945,437);textSize(18);text("SAUCE",945,458);
fill(75);stroke(45);strokeWeight(3);rect(865,320,160,32,7);stroke(130);strokeWeight(2);
for(let x=875;x<=1015;x+=12)line(x,325,x,347);pop();
}
function drawFinishButton(){
noStroke();fill(180,45,30);rect(880,545,130,45,10);fill(255);textAlign(CENTER,CENTER);textSize(18);text("FINISH",945,567);
}
function drawPizzaResults(){
noStroke();fill(0,0,0,130);ellipse(pizzaX,pizzaY,390,390);
fill(255,245,220);stroke(110,80,55);strokeWeight(4);rectMode(CENTER);rect(pizzaX,pizzaY,350,260,20);
noStroke();fill(90,60,40);textAlign(CENTER,CENTER);textSize(28);text("Pizza "+currentPizza+" Complete!",pizzaX,pizzaY-85);
textSize(24);text("Accuracy: "+floor(accuracy)+"%",pizzaX,pizzaY-35);
let stars=getStars(accuracy),s="";for(let i=0;i<5;i++)s+=i<stars?"★ ":"☆ ";
fill(220,160,30);textSize(32);text(s,pizzaX,pizzaY+15);
if(currentPizza<totalPizzas){noStroke();fill(180,45,30);rect(pizzaX,pizzaY+85,180,45,10);fill(255);textSize(17);text("NEXT PIZZA",pizzaX,pizzaY+85);}
rectMode(CORNER);
}
function drawLevelComplete(){
background(42,100,83);noStroke();fill(255,215,105);
beginShape();vertex(125,130);vertex(300,130);vertex(300,265);vertex(125,265);vertex(195,200);endShape(CLOSE);
beginShape();vertex(820,130);vertex(995,130);vertex(925,200);vertex(995,265);vertex(820,265);endShape(CLOSE);
fill(255,225,155);stroke(140,105,60);strokeWeight(2);rectMode(CENTER);rect(560,195,610,185,30);
let avg=getAverageAccuracy(),stars=getAverageStars();
noStroke();fill(0);textAlign(CENTER,CENTER);textSize(44);text("Level Complete",560,185);textSize(28);text("Accuracy: "+floor(avg)+"%",560,240);
for(let i=0;i<5;i++){if(i<stars)fill(255,210,60);else fill(245);stroke(110);strokeWeight(1);drawStar(400+i*80,380,20,42,5);}
noStroke();fill(80,235,45);rect(560,550,410,65,10);fill(0);textSize(21);text("Next Level",560,550);rectMode(CORNER);
}
function getStars(s){if(s>=90)return 5;if(s>=80)return 4;if(s>=70)return 3;if(s>=60)return 2;if(s>=40)return 1;return 0;}
function getAverageAccuracy(){if(!pizzaScores.length)return 0;let t=0;for(let i=0;i<pizzaScores.length;i++)t+=pizzaScores[i];return t/pizzaScores.length;}
function getAverageStars(){if(!pizzaStars.length)return 0;let t=0;for(let i=0;i<pizzaStars.length;i++)t+=pizzaStars[i];return round(t/pizzaStars.length);}
function clearSauce(){sauceLayer.clear();totalSauce=goodSauce=accuracy=0;lastSauceX=lastSauceY=null;ladleX=pizzaX;ladleY=pizzaY;createCoveragePoints();}
function selectShape(s){if(chosenShape!==s&&!gameFinished){chosenShape=s;clearSauce();}}
function finishPizza(){
calculateAccuracy();pizzaScores.push(accuracy);pizzaStars.push(getStars(accuracy));stopSauce();
if(currentPizza===totalPizzas){gameStarted=gameFinished=false;screen="levelComplete";}else{gameFinished=true;gameStarted=false;}
}
function nextPizza(){currentPizza++;gameFinished=false;gameStarted=true;clearSauce();}
function resetLevel(){currentPizza=1;pizzaScores=[];pizzaStars=[];gameStarted=gameFinished=false;chosenShape="Circle";clearSauce();screen="instructions";}
function mousePressed(){
if(screen==="instructions"){if(mouseX>470&&mouseX<650&&mouseY>420&&mouseY<470){screen="game";currentPizza=1;gameStarted=true;gameFinished=false;clearSauce();}return;}
if(screen==="levelComplete"){if(mouseX>355&&mouseX<765&&mouseY>517&&mouseY<583)resetLevel();return;}
if(gameFinished){if(currentPizza<totalPizzas&&mouseX>pizzaX-90&&mouseX<pizzaX+90&&mouseY>pizzaY+62&&mouseY<pizzaY+108)nextPizza();return;}
if(mouseX>65&&mouseX<300){for(let i=0;i<5;i++){let y=215+i*48;if(mouseY>y-20&&mouseY<y+20){selectShape(shapes[i]);return;}}}
if(gameStarted){if(mouseX>880&&mouseX<1010&&mouseY>545&&mouseY<590){finishPizza();return;}if(dist(mouseX,mouseY,pizzaX,pizzaY)<=sauceBoundary)startSauce();}
}
function mouseDragged(){if(screen==="game")spreadSauce();return false;}
function mouseReleased(){stopSauce();return false;}